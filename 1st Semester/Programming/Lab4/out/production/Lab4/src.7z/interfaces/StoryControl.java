package interfaces;

public interface StoryControl {
    void start();
    void end();
}
